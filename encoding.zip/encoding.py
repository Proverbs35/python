import base64 

# FILE NAME - encoding.py

# NAME - 
# DATE - 
# DESCRIPTION - 

  



def main():
    encode_data()

def encode_data():
    # OPEN FILE
    
    
    
    # GET DATA
    
    
    
    # OUTPUT ENCODED DATA






main()
